# 
# Author - Shuber Ali Mirza
# ID ----- 20027047
# 

import matplotlib.pyplot as plt
import sys

# cipher - plain
# v - e
# o - t
# j - a
# z - o
# h - i
# w - n
# l - s
# i - r
# e - h
# q - l
# s - d
# y - f
# m - b
# c - p
# p - c
# t - m
# r - u
# d - y
# b - g
# x - w
# n - k
# f - q
# k - j
# a - x
# g - z

# Lists used for creating bar graph
letters = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
frequency = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

# Taking file as commandline argument
if (len(sys.argv) < 2):
    print('ERROR - No text file given')
    print('USAGE -> python3 letterFreq.py <filename>')
else:
    textFile = str(sys.argv[1])
    
    # Readling contents of file provided
    text = None
    try:
        with open(textFile, 'r') as f:
            text = f.read()
    except OSError as err:
        print("ERROR - Can't open file: ", err)
    except:
        print('ERROR')

    # Comparing characters and incrementing frequency
    s = ''
    for i in text:
        if i.lower() == 'a':
            frequency[0] += 1
            s += 'x'
        elif i.lower() == 'b':
            frequency[1] += 1
            s += 'g'
        elif i.lower() == 'c':
            frequency[2] += 1
            s += 'p'
        elif i.lower() == 'd':
            frequency[3] += 1
            s += 'y'
        elif i.lower() == 'e':
            frequency[4] += 1
            s += 'h'
        elif i.lower() == 'f':
            frequency[5] += 1
            s += 'q'
        elif i.lower() == 'g':
            frequency[6] += 1
            s += 'z'
        elif i.lower() == 'h':
            frequency[7] += 1
            s += 'i'
        elif i.lower() == 'i':
            frequency[8] += 1
            s += 'r'
        elif i.lower() == 'j':
            frequency[9] += 1
            s += 'a'
        elif i.lower() == 'k':
            frequency[10] += 1
            s += 'j'
        elif i.lower() == 'l':
            frequency[11] += 1
            s += 's'
        elif i.lower() == 'm':
            frequency[12] += 1
            s += 'b'
        elif i.lower() == 'n':
            frequency[13] += 1
            s += 'k'
        elif i.lower() == 'o':
            frequency[14] += 1
            s += 't'
        elif i.lower() == 'p':
            frequency[15] += 1
            s += 'c'
        elif i.lower() == 'q':
            frequency[16] += 1
            s += 'l'
        elif i.lower() == 'r':
            frequency[17] += 1
            s += 'u'
        elif i.lower() == 's':
            frequency[18] += 1
            s += 'd'
        elif i.lower() == 't':
            frequency[19] += 1
            s += 'm'
        elif i.lower() == 'u':
            frequency[20] += 1
            s += 'v'
        elif i.lower() == 'v':
            frequency[21] += 1
            s += 'e'
        elif i.lower() == 'w':
            frequency[22] += 1
            s += 'n'
        elif i.lower() == 'x':
            frequency[23] += 1
            s += 'w'
        elif i.lower() == 'y':
            frequency[24] += 1
            s += 'f'
        elif i.lower() == 'z':
            frequency[25] += 1
            s += 'o'
        else:
            s += i
    
    # Writing resulting string to plain.txt file
    with open('plain.txt', 'w') as f:
        f.write(s)
    print('Plaintext written to plain.txt')

#     for i in range(len(letters)):
#         print(letters[i], frequency[i])

#     frequency.sort()
#     print(frequency)

    # Creating bar graph
    graph = plt.bar(letters, frequency)
    plt.xlabel('Alphabets')
    plt.ylabel('Frequency')
    plt.title('Letter Frequency')
    plt.show()
