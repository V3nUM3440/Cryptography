# 
# Author - Shuber Ali Mirza
# ID ----- 20027047
# 

from des import *

# random plaintext
text = 'Shuber Ali Mirza!@#'
# Key initialized to all 0s
key = '0' * 64
print('m = ' + text)
print('k = ' + key, len(key), 'bits')

# PC1 computation
key = permutate(key, 'pc1')
# Converting text to binary
binary = char2bin(text)
# Spliting binary into 64 bit blocks
arr = splitBits(binary, 64)
# Padding last block, to make it 64 bits, if required
plainPad(arr)
# Encrypting
cipher = Encrypt(arr, key)
print('c = ' + cipher)

# Converting hex cipher back to binary
cipherBin = hex2bin(cipher)
# Preparing the binary same as before, by spliting in 64 bit blocks and padding last block
arr = splitBits(cipherBin, 64)
plainPad(arr)
# ENCRYPTING the resulting blocks from the cipher
message = Encrypt(arr, key)
message = bin2char(hex2bin(message))
# Chopping off the padded last block
chopped = False
while chopped == False:
    if message[-1] == 'U':
        message = message[:-1]
    else:
        chopped = True
# Converting hex to text and printing the result
print('m = ' + message, '| after 2nd Encryption, NOT decryption')
