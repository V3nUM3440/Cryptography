# 
# Author - Shuber Ali Mirza
# ID ----- 20027047
# 

# c = cipher text, key(a, b)
def d(c, a, b):
    m = ''
    for i in c:
        if i.isupper():
            char = (a*(ord(i) - ord('A') - b)) % 26
            char = chr(char + ord('A'))
            m += char
        elif i.islower():
            char = (a*(ord(i) - ord('a') - b)) % 26
            char = chr(char + ord('a'))
            m += char
        else:
            m += i
    return m
    
if __name__ == '__main__':
    # All possible "a" values and their inverses
    a = [1, 3, 5, 7, 9, 11, 15, 17, 19, 21, 23, 25]
    a1 = [1, 9, 21, 15, 3, 19, 7, 23, 11, 5, 17, 25]
    
    # Reading first lines from cipher.txt and plain.txt(plaintext found from letter frequency analysis)
    with open('cipher.txt', 'r') as f:
        line1 = f.readline().strip()
    with open('plain.txt', 'r') as f:
        line2 = f.readline().strip()
    
    # Bruteforcing through all key combinations
    hit, aVal, bVal = None, 0, 0
    for i in range(12):
        for j in range(26):
            plain = d(line1, a[i], j)
            # print(plain, f'Key(a:{a[i]}, b:{j})')
            # Comparing all bruteforced results to check if any match with plaintext
            if plain.lower() == line2:
                hit, aVal, bVal = plain, i, j

    print('cipher.txt 1st line:\t\t\t', line1)
    print('1st line from letter analysis:\t\t', line2)
    print('Decryption from affine brute force:\t', hit)
    print(f'Decryption Key(a^-1:{a[aVal]}, b:{bVal})')
    print('Therefore key used to encrypt plaintext = modInverse a^-1 =', a1[aVal])
    print(f'Hence, Encryption Key(a:{a1[aVal]}, b:{bVal})')

    print('\n ----------- Decrypting whole cipher.txt with keys found -----------\n')
    with open('cipher.txt', 'r') as f:
        cipher = f.read()
    plainText = d(cipher, a[aVal], bVal)
    print(plainText)
